package ch.paixon.exercise_architecture.dto;

public class ConnectionDto {

    public DepartureLocationDto from;
    public ArrivalLocationDto to;
}
