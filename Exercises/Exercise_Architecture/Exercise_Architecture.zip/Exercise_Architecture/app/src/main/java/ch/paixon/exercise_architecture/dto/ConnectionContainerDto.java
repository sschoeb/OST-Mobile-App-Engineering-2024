package ch.paixon.exercise_architecture.dto;

import java.util.List;

public class ConnectionContainerDto {

    public List<ConnectionDto> connections;

}
