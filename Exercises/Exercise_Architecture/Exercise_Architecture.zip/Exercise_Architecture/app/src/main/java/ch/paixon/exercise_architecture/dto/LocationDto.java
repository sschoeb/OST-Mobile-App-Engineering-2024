package ch.paixon.exercise_architecture.dto;

public class LocationDto {

}
