package ch.paixon.exercise_architecture.dto;


import java.util.Date;

public class DepartureLocationDto extends LocationDto {

    public Date departure;

}
