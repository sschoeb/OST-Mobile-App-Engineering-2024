package ch.paixon.exercise_layouts_solution;

import android.app.Activity;
import android.os.Bundle;

public class CombinedlayoutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combined_layout);
    }

}
